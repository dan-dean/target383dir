/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_224(unsigned *p)
{
    *p = 3284633920U;
}

unsigned getval_113()
{
    return 502842184U;
}

unsigned addval_452(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_446()
{
    return 1103321130U;
}

void setval_449(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_259()
{
    return 348346400U;
}

void setval_272(unsigned *p)
{
    *p = 3273160029U;
}

unsigned addval_247(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_189()
{
    return 3232023177U;
}

void setval_232(unsigned *p)
{
    *p = 3223376329U;
}

void setval_375(unsigned *p)
{
    *p = 3250751765U;
}

unsigned addval_157(unsigned x)
{
    return x + 2495777214U;
}

unsigned addval_290(unsigned x)
{
    return x + 3281047944U;
}

unsigned addval_252(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_210(unsigned x)
{
    return x + 3281047177U;
}

unsigned addval_395(unsigned x)
{
    return x + 2425475465U;
}

void setval_217(unsigned *p)
{
    *p = 3263809829U;
}

void setval_158(unsigned *p)
{
    *p = 3348156809U;
}

unsigned getval_288()
{
    return 3252717896U;
}

void setval_484(unsigned *p)
{
    *p = 3531129481U;
}

unsigned getval_112()
{
    return 3224949129U;
}

void setval_444(unsigned *p)
{
    *p = 3281047937U;
}

unsigned addval_219(unsigned x)
{
    return x + 3286272332U;
}

unsigned getval_355()
{
    return 2982396617U;
}

unsigned addval_363(unsigned x)
{
    return x + 2496563641U;
}

unsigned addval_279(unsigned x)
{
    return x + 2464188744U;
}

void setval_378(unsigned *p)
{
    *p = 3234124169U;
}

void setval_154(unsigned *p)
{
    *p = 3525365387U;
}

unsigned getval_129()
{
    return 3682914697U;
}

void setval_239(unsigned *p)
{
    *p = 2244136585U;
}

unsigned addval_293(unsigned x)
{
    return x + 3767093267U;
}

unsigned getval_275()
{
    return 3677933193U;
}

unsigned getval_419()
{
    return 3221278345U;
}

void setval_248(unsigned *p)
{
    *p = 3223372425U;
}

unsigned addval_486(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_118()
{
    return 3269495112U;
}

void setval_376(unsigned *p)
{
    *p = 3348156041U;
}

void setval_146(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_229()
{
    return 3229929129U;
}

unsigned getval_468()
{
    return 3281044137U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
